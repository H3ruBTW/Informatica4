package CalendiarioGregoriano;

public class CalendarioMain {
    public static void main(String[] args) {
        CalendarioMetodi1 Cal1 = new CalendarioMetodi1();
        CalendarioMetodi2 Cal2 = new CalendarioMetodi2();

        Cal1.Orario();
        Cal2.Orario();
    }
}
